import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NewMyAppComponent } from './new-my-app.component';

describe('NewMyAppComponent', () => {
  let component: NewMyAppComponent;
  let fixture: ComponentFixture<NewMyAppComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NewMyAppComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NewMyAppComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
