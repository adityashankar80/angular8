import { Component, OnInit } from '@angular/core';
import { $ } from '../../../node_modules/jquery';
@Component({
  selector: 'app-new-my-app',
  templateUrl: './new-my-app.component.html',
  styleUrls: ['./new-my-app.component.css']
})
export class NewMyAppComponent implements OnInit {
  userlist: Users[];
  constructor() { 
    this.userlist=[{Id:'1',name:'Aruna',phone:'980453478',email:'aruna2@gmail.com',site:'http://www.aruna.co.in',imageUrl:'../assets/images/img_5terre.jpg'},
    {Id:'2',name:'Mina',phone:'980453472',email:'min@gmail.com',site:'http://www.mina.com',imageUrl:'../assets/images/img_forest.jpg'},
    {Id:'3',name:'Rakesh',phone:'980453473',email:'rk@gmail.com',site:'http://www.rakesh.co.in',imageUrl:'../assets/images/img_lights.jpg'},
    {Id:'4',name:'Karan',phone:'980453474',email:'karan@gmail.com',site:'http://www.karan.co.in',imageUrl:'../assets/images/img_mountains.jpg'},
    {Id:'5',name:'Gautam',phone:'980453475',email:'gtatum@gmail.com',site:'http://www.gautam.co.in',imageUrl:'../assets/images/img_mountains.jpg'}];
  
    this.userlist.sort(this.dynamicSort("name"));
    console.log(this.userlist)
  }
 
  ngOnInit() {
  }
  userName:any;
  userPhone:any;
  userEmail:any;
  userImage:any;
  display='none';
  clickMe(item) {
   console.log(item);
   this.userName = item.name;
   this.userPhone = item.phone;
   this.userEmail = item.email;
   this.userImage = item.imageUrl
   this.display='block'; 
}
onCloseHandled(){
  this.display='none'; 
}

 dynamicSort(property) {
  var sortOrder = 1;

  if(property[0] === "-") {
      sortOrder = -1;
      property = property.substr(1);
  }

  return function (a,b) {
      if(sortOrder == -1){
          return b[property].localeCompare(a[property]);
      }else{
          return a[property].localeCompare(b[property]);
      }        
  }
}
}


export class Users {
  Id: String;
  name: String;
  phone:String;
  email:String
  site: String;
  imageUrl:String

}

