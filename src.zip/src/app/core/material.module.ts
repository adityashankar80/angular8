import {NgModule} from "@angular/core";
import { CommonModule } from '@angular/common';
//import {MatFormFieldModule} from '@angular/material/form-field';
import {
  MatButtonModule, MatNativeDateModule, MatIconModule, MatSidenavModule, MatListModule, MatToolbarModule,MatFormFieldModule} from '@angular/material';

@NgModule({
  imports: [CommonModule, MatButtonModule,MatToolbarModule, MatNativeDateModule, MatIconModule, MatSidenavModule, MatListModule,MatFormFieldModule],
  exports: [CommonModule, MatButtonModule, MatToolbarModule, MatNativeDateModule, MatIconModule, MatSidenavModule, MatListModule,MatFormFieldModule],
})
export class CustomMaterialModule { }
