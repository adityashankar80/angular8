import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AboubtusAppComponent } from './aboubtus-app.component';

describe('AboubtusAppComponent', () => {
  let component: AboubtusAppComponent;
  let fixture: ComponentFixture<AboubtusAppComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AboubtusAppComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AboubtusAppComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
