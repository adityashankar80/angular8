import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-aboubtus-app',
  templateUrl: './aboubtus-app.component.html',
  styleUrls: ['./aboubtus-app.component.css']
})
export class AboubtusAppComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
