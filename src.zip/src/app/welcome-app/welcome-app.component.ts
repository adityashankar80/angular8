import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup} from '@angular/forms';
import { Router, CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
@Component({
  selector: 'app-welcome-app',
  templateUrl: './welcome-app.component.html',
  styleUrls: ['./welcome-app.component.css']
})
export class WelcomeAppComponent implements OnInit {

  constructor(private router: Router) { }

  ngOnInit() {
  }
  gotoLogout(){
    this.router.navigate(['/login']);
  }

  
}
