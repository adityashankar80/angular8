import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NewMyAppComponent } from './new-my-app/new-my-app.component';
import { NewsAppComponent } from './news-app/news-app.component';
import { ContactAppComponent } from './contact-app/contact-app.component';
import { AboubtusAppComponent } from './aboubtus-app/aboubtus-app.component';
import { LoginAppComponent } from './login-app/login-app.component';
import { WelcomeAppComponent } from './welcome-app/welcome-app.component';
import { FormsModule } from '@angular/forms';
import {CustomMaterialModule} from "./core/material.module";

@NgModule({
  declarations: [
    AppComponent,
    NewMyAppComponent,
    NewsAppComponent,
    ContactAppComponent,
    AboubtusAppComponent,
    LoginAppComponent,
    WelcomeAppComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    CustomMaterialModule,
    BrowserAnimationsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
