import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-news-app',
  templateUrl: './news-app.component.html',
  styleUrls: ['./news-app.component.css']
})
export class NewsAppComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
