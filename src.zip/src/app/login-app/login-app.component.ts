import { Component, OnInit } from '@angular/core';
import { Router, CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
@Component({
  selector: 'app-login-app',
  templateUrl: './login-app.component.html',
  styleUrls: ['./login-app.component.css']
})
export class LoginAppComponent implements OnInit {
  userName:any;
  uPassword:any;
  constructor(private router: Router) { }

  ngOnInit() {
  }
  onClickSubmit(data) {
    debugger
    this.userName = data.emailid;
    this.uPassword = data.uPassword;
    if(this.userName=="newgen" && this.uPassword=="trigger"){
      this.router.navigate(['/welcome']);
    }else{
      alert("Invalid Credential");
    }
  }
}
