import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { NewMyAppComponent } from './new-my-app/new-my-app.component';
import { NewsAppComponent } from './news-app/news-app.component';
import { ContactAppComponent } from './contact-app/contact-app.component';
import { AboubtusAppComponent } from './aboubtus-app/aboubtus-app.component';
import { LoginAppComponent } from './login-app/login-app.component';
import { WelcomeAppComponent } from './welcome-app/welcome-app.component';

const routes: Routes = [
{path:'',redirectTo:'login', pathMatch: 'full' },
 { path: 'login', component: LoginAppComponent },
 { path: 'welcome', component: WelcomeAppComponent,
 children: [
  { path: '', redirectTo: 'newcmp', pathMatch: 'full'},
  { path: 'newcmp', component: NewMyAppComponent },
  { path: 'news', component: NewsAppComponent },
  { path: 'contact', component: ContactAppComponent },
  { path: 'aboutus', component: AboubtusAppComponent }
] 
},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
